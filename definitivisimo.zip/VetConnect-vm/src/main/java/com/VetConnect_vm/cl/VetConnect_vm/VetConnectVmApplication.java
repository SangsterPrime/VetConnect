package com.VetConnect_vm.cl.VetConnect_vm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VetConnectVmApplication {

	public static void main(String[] args) {
		SpringApplication.run(VetConnectVmApplication.class, args);
	}

}
