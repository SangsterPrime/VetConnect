package com.VetConnect_vm.cl.VetConnect_vm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetConnectVmApplicationTests {

	@Test
	void contextLoads() {
	}

}
